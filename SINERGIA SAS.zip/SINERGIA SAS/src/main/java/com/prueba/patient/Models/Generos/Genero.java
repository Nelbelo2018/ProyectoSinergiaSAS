package com.prueba.patient.Models.Generos;

public enum Genero {

    HOMBRE,MUJER,GAY,
}
